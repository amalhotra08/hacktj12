//
//  ContentView.swift
//  SafeScape
//
//  Created by Armaan Ahmed on 3/8/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
//            Home()
            ChooseRole()
        }
    }
}

#Preview {
    ContentView()
}
