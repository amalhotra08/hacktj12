//
//  SafeScapeApp.swift
//  SafeScape
//
//  Created by Armaan Ahmed on 3/8/25.
//

import SwiftUI

@main
struct SafeScapeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
