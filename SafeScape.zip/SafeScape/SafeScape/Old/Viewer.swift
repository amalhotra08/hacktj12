//
//  Viewer.swift
//  SafeScape
//
//  Created by Armaan Ahmed on 3/8/25.
//

import SwiftUI
import SceneKit

struct Viewer: View {
    @State var name: String
    var peopleLocations: [SCNVector3]
    var waypointLocations: [SCNVector3]
    var lines: [SCNGeometry]
    @State var count = 0
    @State var onTapped: (() -> Void)
    
    var body: some View {
        VStack {
            SceneView(scene: {
                let scene = SCNScene(named: name + ".usdz") ?? SCNScene()
                scene.background.contents = UIColor.systemGray6
                
                for location in peopleLocations {
                    let sphere = SCNNode(geometry: SCNSphere(radius: 0.3))
                    sphere.geometry?.firstMaterial?.diffuse.contents = UIColor.blue
                    sphere.position = location
                    scene.rootNode.addChildNode(sphere)
                }
                
                for location in waypointLocations {
                    let sphere = SCNNode(geometry: SCNSphere(radius: 0.3))
                    sphere.geometry?.firstMaterial?.diffuse.contents = UIColor.green
                    sphere.position = location
                    scene.rootNode.addChildNode(sphere)
                }
                
                for line in lines {
                    scene.rootNode.addChildNode(SCNNode(geometry: line))
                }
                
                return scene
            }(), options: [.autoenablesDefaultLighting, .allowsCameraControl])
                .edgesIgnoringSafeArea(.all)
                .onTapGesture { location in
                    onTapped()
                }
        }
    }
}

#Preview {
//    Viewer(name: "Room", par)
    Viewer(name: "Room", peopleLocations: [], waypointLocations: [], lines: []) {
        print("hi")
    }
}

extension SCNGeometry {
    class func lineFrom(vector vector1: SCNVector3, toVector vector2: SCNVector3) -> SCNGeometry {
        
        let indices: [Int32] = [0, 1]

        let source = SCNGeometrySource(vertices: [vector1, vector2])
        let element = SCNGeometryElement(indices: indices, primitiveType: .line)

        return SCNGeometry(sources: [source], elements: [element])

    }
}
