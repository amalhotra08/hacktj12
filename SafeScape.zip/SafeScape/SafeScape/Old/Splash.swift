//
//  SwiftUIView.swift
//  HackTJ
//
//  Created by Armaan School on 3/8/25.
//

import SwiftUI

struct Splash: View {
    
    @Binding var popover: Bool
    
    var body: some View {
        VStack {
            Spacer()
                .frame(height: 50)
            Image("logo")
                .resizable()
                .scaledToFit()
                .frame(width: 100)
            Text("HackTJ 2025")
                .font(.system(size: 32, weight: .heavy))
                .padding()
            SplashElement(title: "Real-Time AR Escape Routes", description: "Navigate emergencies with dynamic AR paths tailored to your location.", systemName: "arrow.up")
            SplashElement(title: "Crowdsourced 3D Mapping", description: "Users’ cameras collaboratively build a live model for improved situational awareness.", systemName: "square.split.bottomrightquarter")
            SplashElement(title: "First Responder Integration", description: "Firefighters receive real-time building visuals and hazard reports for safer rescues.", systemName: "phone")
            Spacer()
            HStack {
                Spacer()
                Button("Continue") {
                    popover = false
                }
                .foregroundStyle(.white)
                .bold()
                Spacer()
            }
            .padding()
            .background(.link)
            .cornerRadius(20)
            .shadow(radius: 5)
            .onTapGesture {
                popover = false
            }
        }
        .padding()
    }
}

struct SplashElement: View {
    
    @State var title: String
    @State var description: String
    @State var systemName: String
    
    var body: some View {
        HStack {
            Image(systemName: systemName)
                .resizable()
                .scaledToFit()
                .frame(width: 30)
                .padding(.trailing)
                .foregroundStyle(.link)
            VStack {
                HStack {
                    Text(title)
                        .bold()
                    Spacer()
                }
                HStack {
                    Text(description)
                        .foregroundStyle(.gray)
                    Spacer()
                }
            }
        }
        .padding()
    }
}

#Preview {
    Splash(popover: .constant(true))
}
