//
//  Home.swift
//  SafeScape
//
//  Created by Armaan Ahmed on 3/8/25.
//

import SwiftUI

struct Home: View {
    @State var popover = true
    @State var showOverlay = false
    var barButtonColor = Color.black
    var body: some View {
        ZStack {
            List {
                NavigationLink {
//                    Viewer(name: "Room")
                    Text("Hi")
                } label: {
                    Text("Floor 1")
                }
            }
            VStack {
                Spacer()
            }
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Button("FIRE") {
                        popover = false
                    }
                    .foregroundStyle(.black)
                    .fontWeight(.heavy)
                    Spacer()
                }
                .padding()
                .background(.orange)
                .cornerRadius(20)
                .shadow(radius: 5)
                .onTapGesture {
                    popover = false
                }
            }
            .padding()
        }
        .sheet(isPresented: $popover) {
            Splash(popover: $popover)
                .presentationDetents([.fraction(0.99)])
        }
        .fullScreenCover(isPresented: $showOverlay, content: {
            NavigationView {
                RoomPlanView(showOverlay: $showOverlay)
            }
        })
        .navigationTitle("Saved Locations")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                HStack(spacing: 0) {
                    Button {
                        showOverlay = true
                    } label: {
                        Text("Add")
                            .padding(5)
                            .padding(.horizontal, 10)
                            .background(barButtonColor)
                            .cornerRadius(20)
                            .foregroundStyle(.white)
                            .bold()
                    }
                }
            }
        }
        .background(Color(uiColor: .systemGray6))

    }
}

#Preview {
    NavigationView {
        Home()
    }
}
