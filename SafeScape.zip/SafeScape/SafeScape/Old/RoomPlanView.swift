//
//  RoomPlanView.swift
//  RoomPlanSwiftUI
//
//  Created by tiyas aria on 10/12/23.
//

import SwiftUI

struct RoomPlanView: View {
    @Binding var showOverlay: Bool
    var roomController = RoomController.instance
    @State private var doneScanning : Bool = false
    var body: some View {
        ZStack{
            RoomCaptureViewRepresentable()
                .onAppear(perform: {
                    roomController.startSession()
                })
            VStack {
                Spacer()
                Button(action: {
                    roomController.stopSession()
                    self.doneScanning = true
                    // MARK: - Upload usdz here
                    showOverlay = false
                }, label: {
                    Text("Done")
                        .padding(20)
                        .background(.orange)
                        .foregroundStyle(.black)
                        .fontWeight(.heavy)
                })
                .background(.orange)
//                .buttonStyle(.borderedProminent)
                .cornerRadius(30)
                .bold()
                .shadow(radius: 10)
            }
            .padding()
        }
    }
}

#Preview {
    RoomPlanView(showOverlay: .constant(true))
}
