import SwiftUI
import AlertToast
import MapKit
import SceneKit

struct UserDashboard: View {
    
    @State var selected = 2
    
    var body: some View {
        ZStack {
            Color(hex: "#12192C")
                .edgesIgnoringSafeArea(.all)

            TabView(selection: $selected) {
                UserARView()
                    .tabItem {
                        Label("AR", systemImage: "camera.fill")
                    }
                    .tag(1)

                UserMapUserView()
                    .tabItem {
                        Label("Map", systemImage: "map.fill")
                    }
                    .tag(2)

                UserChatView()
                    .tabItem {
                        Label("Chat", systemImage: "message.fill")
                    }
                    .tag(3)
            }
            .accentColor(Color(hex: "#FF3D00"))
            .navigationBarBackButtonHidden()
        }
    }
}

struct UserARView: View {
    var body: some View {
        VStack {
            ARDirectionalPlanning()
            Spacer().frame(height: 10)
        }
    }
}

struct UserMapUserView: View {
    @State private var peopleLocations: [SCNVector3] = []
    @State private var waypointLocations: [SCNVector3] = []
    @State private var lines: [SCNGeometry] = []
    
    @State var appeared = false
    
    var body: some View {
        VStack {
            HStack {
                Text("Emergency Map")
                    .font(.title3)
                    .bold()
                    .foregroundStyle(.ud)
                Spacer()
                Button {
                    print("call tapped")
                } label: {
                    HStack {
                        Image(systemName: "phone.fill")
                            .foregroundStyle(.ud)
                        Text("Call")
                            .foregroundStyle(.ud)
                            .fontWeight(.bold)
                    }
                    .padding(.horizontal, 18)
                    .padding(.vertical, 12)
                    .background(
                        RoundedRectangle(cornerRadius: 14)
                            .fill(.white) // Darker Blue Button Background
                            .shadow(color: Color.black.opacity(0.6), radius: 6, x: 3, y: 3)
                            .shadow(color: Color.white.opacity(0.1), radius: 6, x: -3, y: -3)
                    )
                }
            }
            .padding()
            .background(.white)
            .clipShape(RoundedRectangle(cornerRadius: 14))
//            HStack {
//                Text("Emergency Map")
//                    .font(.title3)
//                    .bold()
//                    .foregroundColor(Color(hex: "#FF3D00"))
//                Spacer()
//                Button(action: {
//                    print("Call button tapped")
//                }) {
//                    HStack {
//                        Image(systemName: "phone.fill")
//                            .foregroundColor(Color(hex: "#FF3D00"))
//                        Text("Call")
//                            .foregroundColor(Color(hex: "#FF3D00"))
//                            .fontWeight(.bold)
//                    }
//                    .padding(.horizontal, 18)
//                    .padding(.vertical, 12)
//                    .background(
//                        RoundedRectangle(cornerRadius: 14)
//                            .fill(.white) // Darker Blue Button Background
//                            .shadow(color: Color.black.opacity(0.6), radius: 6, x: 3, y: 3)
//                            .shadow(color: Color.white.opacity(0.1), radius: 6, x: -3, y: -3)
//                    )
//                }
//            }
//            .padding()
//            .background(.white)
//            .clipShape(RoundedRectangle(cornerRadius: 14))
            Viewer(name: "Room", peopleLocations: peopleLocations, waypointLocations: waypointLocations, lines: lines, onTapped: {
                print("")
            })
                .edgesIgnoringSafeArea(.all)
            
            Spacer().frame(height: 10)
        }
        .background(.white)
        .onAppear {
            if !appeared {
                generateRandomPoints()
                appeared = true
            }
        }
    }
    
    private func generateRandomPoints() {
//        peopleLocations = (0..<10).map { _ in
//            SCNVector3(Float.random(in: 7...26), -1, Float.random(in: -2...10))
//        }
        let p1 = SCNVector3(0, -1, 0)
        let p2 = SCNVector3(3, -1, 10)
        let p3 = SCNVector3(12, -1, 7.5)
        let p4 = SCNVector3(14, -1, 13)
        peopleLocations = [p1]
        waypointLocations = [p4]
        lines = [SCNGeometry.lineFrom(vector: p1, toVector: p2), SCNGeometry.lineFrom(vector: p2, toVector: p3), SCNGeometry.lineFrom(vector: p3, toVector: p4)]
//        waypointLocations = (0..<5).map { _ in
//            SCNVector3(Float.random(in: -2...2), 0, Float.random(in: -2...2))
//        }
    }
}

struct UserChatView: View {
    @State private var messages: [Message] = [
        Message(text: "Hello, I am your first responder. Please describe your emergency.", isIncoming: true)
    ]
    @State private var newMessage: String = ""
    @State var showSecure = true
    
    var body: some View {
        VStack {
            // CHAT MESSAGES
            ScrollViewReader { scrollView in
                ScrollView {
                    VStack(spacing: 12) {
                        ForEach(messages) { message in
                            MessageBubble(message: message)
                                .id(message.id)
                        }
                    }
                    .padding()
                }
                .onChange(of: messages.count) { _ in
                    if let lastMessage = messages.last {
                        withAnimation {
                            scrollView.scrollTo(lastMessage.id, anchor: .bottom)
                        }
                    }
                }
            }
            
            Divider()
            
            // MESSAGE INPUT FIELD
            HStack {
                TextField("Type a message...", text: $newMessage)
                    .padding(14)
                    .background(
                        RoundedRectangle(cornerRadius: 18)
                            .fill(.white) // Dark Blue Input Field
                            .shadow(color: Color.black.opacity(0.6), radius: 6, x: 3, y: 3)
                            .shadow(color: Color.white.opacity(0.1), radius: 6, x: -3, y: -3)
                    )
                    .foregroundColor(Color(hex: "#12192C"))

                Button(action: sendMessage) {
                    Image(systemName: "paperplane.fill")
                        .foregroundColor(.white)
                        .padding(16)
                        .background(
                            Circle()
                                .fill(LinearGradient(gradient: Gradient(colors: [Color.red.opacity(0.9), Color.orange.opacity(0.7)]), startPoint: .top, endPoint: .bottom))
                                .shadow(color: Color.red.opacity(0.7), radius: 10, x: 0, y: 5)
                        )
                }
            }
            .padding()
        }
        .background(.white) // Dark Blue Background
        .navigationTitle("Chat")
        .toast(isPresenting: $showSecure) {
            AlertToast(displayMode: .hud, type: .regular, title: "Secure channel for communication established")
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                self.showSecure = false
            }
        }
    }
    
    private func sendMessage() {
        guard !newMessage.trimmingCharacters(in: .whitespaces).isEmpty else { return }
        let message = Message(text: newMessage, isIncoming: false)
        messages.append(message)
        newMessage = ""
    }
}

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let r, g, b: Double
        r = Double((int >> 16) & 0xFF) / 255.0
        g = Double((int >> 8) & 0xFF) / 255.0
        b = Double(int & 0xFF) / 255.0
        self.init(red: r, green: g, blue: b)
    }
}

#Preview {
    UserDashboard()
}
