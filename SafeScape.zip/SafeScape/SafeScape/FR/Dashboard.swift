import SwiftUI
import AlertToast
import MapKit
import SceneKit

struct Dashboard: View {
    
    @State var selected = 2
    
    var body: some View {
        TabView(selection: $selected) {
            ARViewScreen()
                .tabItem {
                    Label("AR", systemImage: "camera.fill")
                }
                .tag(1)

            MapUserView()
                .tabItem {
                    Label("Map", systemImage: "map.fill")
                }
                .tag(2)
            ChatView()
                .tabItem {
                    Label("Chat", systemImage: "bolt.horizontal.circle.fill")
                }
                .tag(3)
        }
        .navigationBarBackButtonHidden()
    }
}

struct ARViewScreen: View {
    var body: some View {
        VStack {
            ARDirectionalPlanning()
            Spacer().frame(height: 10)
        }
    }
}

struct MapUserView: View {
    @State private var peopleLocations: [SCNVector3] = []
    @State private var waypointLocations: [SCNVector3] = []
    @State private var notifications: [String] = []
    
    let demoMessages = [
        "Emergency! Need help!",
        "Assistance required immediately!",
        "Urgent! Someone needs help nearby!"
    ]
    
    @State var appeared = false
    @State var count = 0
    
    var body: some View {
        ZStack {
            VStack {
                Viewer(name: "Room", peopleLocations: peopleLocations, waypointLocations: waypointLocations, lines: [], onTapped: {
                    print(count)
                    if count == 0 {
                        waypointLocations.append(SCNVector3(
                            Float.random(in: 7...26),
                            -1,
                            Float.random(in: -2...10)
                        ))
                    }
                })
                    .edgesIgnoringSafeArea(.all)
                Spacer().frame(height: 10)
            }
            
            VStack {
                ForEach(notifications, id: \..self) { message in
                    NotificationPopup(message: message)
                        .transition(.move(edge: .top).combined(with: .opacity))
                }
                Spacer()
            }
            .animation(.easeInOut, value: notifications)
            .padding(.top, 50)
        }
        .onAppear {
            if !appeared {
                generateRandomPoints()
//                triggerNotificationCycle()
                appeared = true
            }
        }
    }
    
    private func generateRandomPoints() {
//        peopleLocations = (0..<10).map { _ in
//            SCNVector3(
//                Float.random(in: 7...26),
//                -1,
//                Float.random(in: -2...10)
//            )
//        }
        peopleLocations = [
            SCNVector3(0, -1, 0),
            SCNVector3(4, -1, 10),
            SCNVector3(10.5, -1, 0),
            SCNVector3(14, -1, 13)
        ]
        let p4 = SCNVector3(14, -1, 13)
        waypointLocations = [p4]
//        waypointLocations = (0..<5).map { _ in
//            SCNVector3(
//                Float.random(in: -2...2),
//                0,
//                Float.random(in: -2...2)
//            )
//        }
    }
    
    private func triggerNotificationCycle() {
        Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { _ in
            if let newMessage = demoMessages.randomElement() {
                withAnimation {
                    notifications.insert(newMessage, at: 0)
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    withAnimation {
                        if notifications.count > 2 {
                            notifications.removeLast()
                        }
                    }
                }
            }
        }
    }
}

struct NotificationPopup: View {
    let message: String
    
    var body: some View {
        Text(message)
            .padding()
            .background(Color.red.opacity(0.9))
            .foregroundColor(.white)
            .cornerRadius(10)
            .shadow(radius: 3)
    }
}

struct ChatView: View {
    @State private var messages: [Message] = [
        Message(text: "Hello, I am your first responder. Please describe your emergency.", isIncoming: true)
    ]
    @State private var newMessage: String = ""
    @State var showSecure = true
    
    var body: some View {
        VStack {
            // CHAT MESSAGES
            ScrollViewReader { scrollView in
                ScrollView {
                    VStack(spacing: 12) {
                        ForEach(messages) { message in
                            MessageBubble(message: message)
                                .id(message.id)
                        }
                    }
                    .padding()
                }
                .onChange(of: messages.count) { _ in
                    if let lastMessage = messages.last {
                        withAnimation {
                            scrollView.scrollTo(lastMessage.id, anchor: .bottom)
                        }
                    }
                }
            }
            
            Divider()
            
            // MESSAGE INPUT FIELD
            HStack {
                TextField("Type a message...", text: $newMessage)
                    .padding(14)
                    .background(
                        RoundedRectangle(cornerRadius: 18)
                            .fill(.white) // Dark Blue Input Field=
                            .shadow(radius: 10)
                    )
                    .foregroundColor(Color(hex: "#12192C"))

                Button(action: sendMessage) {
                    Image(systemName: "paperplane.fill")
                        .foregroundColor(.white)
                        .padding(16)
                        .background(
                            Circle()
                                .fill(LinearGradient(gradient: Gradient(colors: [Color.red.opacity(0.9), Color.orange.opacity(0.7)]), startPoint: .top, endPoint: .bottom))
                                .shadow(color: Color.red.opacity(0.7), radius: 10, x: 0, y: 5)
                        )
                }
            }
            .padding()
        }
        .background(.white) // Dark Blue Background
        .navigationTitle("Chat")
        .toast(isPresenting: $showSecure) {
            AlertToast(displayMode: .hud, type: .regular, title: "Secure channel for communication established")
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                self.showSecure = false
            }
        }
    }
    
    private func sendMessage() {
        guard !newMessage.trimmingCharacters(in: .whitespaces).isEmpty else { return }
        let message = Message(text: newMessage, isIncoming: false)
        messages.append(message)
        newMessage = ""
    }
}

struct Message: Identifiable {
    let id = UUID()
    let text: String
    let isIncoming: Bool
}

struct MessageBubble: View {
    var message: Message
    
    var body: some View {
        HStack {
            if message.isIncoming {
                Text(message.text)
                    .padding()
                    .background(Color.blue.opacity(0.1))
                    .foregroundColor(.black)
                    .cornerRadius(15)
                Spacer()
            } else {
                Spacer()
                Text(message.text)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(15)
                    .shadow(radius: 2)
            }
        }
        .padding(message.isIncoming ? .leading : .trailing, 16)
    }
}

#Preview {
    Dashboard()
}
