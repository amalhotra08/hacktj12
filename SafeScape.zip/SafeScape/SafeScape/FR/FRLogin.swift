//
//  FRLogin.swift
//  SafeScape
//
//  Created by Armaan Ahmed on 3/8/25.
//

import SwiftUI

struct FRLogin: View {
    @State private var idNumber: String = ""
    @State private var isLoggedIn: Bool = false

    var body: some View {
        VStack {
            Text("Enter ID Number")
                .font(.system(size: 30, weight: .bold))
                .padding(.horizontal)
                .multilineTextAlignment(.center)
                .foregroundStyle(.black)
            HStack {
                Image(systemName: "person.fill")
                    .foregroundColor(.gray)
                    .padding(.leading, 10)
                TextField("ID Number", text: $idNumber)
                    .padding()
                    .keyboardType(.numberPad)
                    .textFieldStyle(PlainTextFieldStyle())
            }
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .strokeBorder(Color.gray, lineWidth: 1)
            )
            .padding(.bottom, 20)
            Spacer()
            HStack {
                Spacer()
                Button("Log In") {
                    if idNumber == "12345" {
                        isLoggedIn = true
                    } else {
                        isLoggedIn = false
                    }
                }
                .foregroundStyle(.white)
                .fontWeight(.heavy)
                Spacer()
            }
            .padding()
            .background(Color("black"))
            .cornerRadius(20)
            .shadow(radius: 5)
            .onTapGesture {
                
            }
            .navigationDestination(isPresented: $isLoggedIn) {
                Dashboard()
            }
        }
        .padding()
    }
}

#Preview {
    NavigationView {
        FRLogin()
    }
}
