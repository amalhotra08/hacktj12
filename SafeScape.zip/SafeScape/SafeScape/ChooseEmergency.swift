//
//  Login.swift
//  SafeScape
//
//  Created by Armaan Ahmed on 3/9/25.
//


import SwiftUI

struct ChooseEmergency: View {
    var body: some View {
        VStack {
            Text("Choose your emergency")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.top, 80)
            
            Spacer()
            
            VStack(spacing: 30) {
                HStack(spacing: 30) {
                    EmergencyButton(color: .red, icon: "flame.fill") // Fire
                    EmergencyButton(color: .black, icon: "exclamationmark.triangle.fill") // Active Shooter
                }
                HStack(spacing: 30) {
                    EmergencyButton(color: .blue, icon: "water.waves") // Flood/Earthquake
                    EmergencyButton(color: .gray, icon: "questionmark.circle.fill") // Other Emergency
                }
            }
            .padding(.bottom, 200)
            
            Spacer()
        }
        .padding(10)
    }
}

struct EmergencyButton: View {
    var color: Color
    var icon: String
    
    var body: some View {
        NavigationLink {
            UserDashboard()
        } label: {
            ZStack {
                Circle()
                    .fill(color)
                    .frame(width: 120, height: 140)
                    .shadow(radius: 30)
                
                Image(systemName: icon)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 50, height: 50)
                    .foregroundColor(.white)
            }
        }
    }
}

#Preview {
    ChooseEmergency()
}
