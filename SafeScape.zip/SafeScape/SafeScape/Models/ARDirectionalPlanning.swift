//
//  ARDirectionalPlanning.swift
//  SafeScape
//
//  Created by Armaan Ahmed on 3/9/25.
//

import SwiftUI
import ARKit
import RealityKit
import CoreLocation

struct ARDirectionalPlanning: View {
    @StateObject var locationManager = LocationManager()
    
    var body: some View {
        ZStack {
            if let userLocation = locationManager.lastLocation {
                ARViewContainer(coordinates: loadCoordinates(), userLocation: userLocation)
                    .edgesIgnoringSafeArea(.all)
            } else {
                VStack {
                    Text("Fetching Location...")
                        .font(.title)
                        .foregroundColor(.gray)
                    
                    Text("Waiting for GPS...")
                        .font(.subheadline)
                        .foregroundColor(.blue)
                }
            }
        }
        .onAppear {
            locationManager.checkAuthorizationAndRequestLocation()
        }
    }
    
    func loadCoordinates() -> [(latitude: Double, longitude: Double)] {
//        return [
//            (38.921867178036536, -77.23402143446997),
//            (38.92181473836698, -77.23414458808334),
//            (38.921791541809476, -77.2339881969759),
//            (38.92176318027435, -77.23386395129434),
//            (38.921706135177125, -77.23344906567569),
//            (38.92176932192195, -77.2333584109762),
//            (38.92180713146326, -77.23325324712654),
//            (38.92185641950371, -77.23326888265943),
//            (38.921813545784836, -77.23340182572345),
//            (38.921701563558464, -77.23350903026501),
//            (38.92164913475413, -77.23353769637386),
//            (38.92172685368138, -77.23346312990739),
//            (38.9217032003423, -77.23359455364495),
//            (38.92167597263975, -77.23373115252316),
//            (38.921722176644806, -77.23392981002038)
//        ]
        var coordinates = [(Double, Double)]()
        for i in 0...8 {
            coordinates.append((locationManager.lastLocation!.coordinate.latitude + (0.000004 * Double(i)), locationManager.lastLocation!.coordinate.longitude * 1.0))
        }
        for i in 0...22 {
            let lon = (locationManager.lastLocation!.coordinate.longitude * 1.0) - (0.000004 * Double(i))
            coordinates.append((locationManager.lastLocation!.coordinate.latitude + (0.000004 * Double(8)), lon))
        }
        for i in 0...5 {
            let lon = (locationManager.lastLocation!.coordinate.longitude * 1.0) - (0.000004 * Double(22))
            coordinates.append((locationManager.lastLocation!.coordinate.latitude + (0.000004 * Double(8 + i)), lon))
        }
        return coordinates
    }
}

