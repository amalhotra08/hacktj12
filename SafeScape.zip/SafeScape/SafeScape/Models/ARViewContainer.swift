//
//  ARViewContainer.swift
//  ARArrowApp
//
//  Created by Pratham Singh on 3/8/25.
//
import SwiftUI
import ARKit
import RealityKit

struct ARViewContainer: UIViewRepresentable {
    var coordinates: [(latitude: Double, longitude: Double)]
    var userLocation: CLLocation
    
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = [.horizontal]
        arView.session.run(config)
        
        context.coordinator.setupScene(for: arView, with: coordinates, userLocation: userLocation)
        return arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator()
    }
    
    class Coordinator {
        func setupScene(for arView: ARView, with coordinates: [(Double, Double)], userLocation: CLLocation) {
            guard coordinates.first != nil else { return }
            let originLat = userLocation.coordinate.latitude
            let originLon = userLocation.coordinate.longitude
            
            let metersPerDegreeLat: Float = 111320.0
            let metersPerDegreeLon: Float = Float(cos(originLat * .pi / 180.0) * 111320.0)
            
            for coord in coordinates {
                let deltaLat = coord.0 - originLat
                let deltaLon = coord.1 - originLon
                
                let position = SIMD3<Float>(
                    Float(deltaLon) * metersPerDegreeLon,
                    0,
                    -Float(deltaLat) * metersPerDegreeLat
                )
                
                let arrowEntity = createArrowEntity()
                arrowEntity.position = position
                
                let anchor = AnchorEntity(world: position)
                anchor.addChild(arrowEntity)
                arView.scene.addAnchor(anchor)
            }
        }
        
        func createArrowEntity() -> ModelEntity {
            let mesh = MeshResource.generateBox(size: [0.2, 0.1, 0.5])
            let material = SimpleMaterial(color: .red, isMetallic: false)
            return ModelEntity(mesh: mesh, materials: [material])
        }
    }
}
