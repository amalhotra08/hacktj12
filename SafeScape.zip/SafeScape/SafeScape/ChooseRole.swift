//
//  ChooseRole.swift
//  SafeScape
//
//  Created by Armaan Ahmed on 3/8/25.
//

import SwiftUI

struct ChooseRole: View {
    var body: some View {
        VStack {
            Spacer().frame(height: 30)
            Text("Welcome to SafeScape")
                .font(.system(size: 30, weight: .bold))
                .padding(.horizontal)
                .multilineTextAlignment(.center)
                .foregroundStyle(.black)
            Text("Description Here")
                .foregroundStyle(.black)
            Spacer()
            Image("logo")
                .resizable()
                .scaledToFit()
                .cornerRadius(20)
                .frame(width: 150)
                .shadow(radius: 10)
            Spacer()
            HStack {
                Spacer()
                NavigationLink("Emergency") {
                    ChooseEmergency()
                }
                .foregroundStyle(Color.white)
                .fontWeight(.heavy)
                Spacer()
            }
            .padding()
            .background(Color("darkblue"))
            .cornerRadius(20)
            .shadow(radius: 5)
            .onTapGesture {
                
            }
            HStack {
                Spacer()
                NavigationLink("First Respondence") {
                    FRLogin()
                }
                .foregroundStyle(.white)
                .fontWeight(.heavy)
                Spacer()
            }
            .padding()
            .background(Color("black"))
            .cornerRadius(20)
            .shadow(radius: 5)
            .onTapGesture {
                
            }
        }
        .padding()
//        .background(Color("darkblue"))
//        .background(
//            LinearGradient(gradient: Gradient(colors: [Color("darkblue"), Color("darkblue").opacity(0.9)]), startPoint: .top, endPoint: .bottom)
//        )
    }
}

#Preview {
    NavigationView {
        ChooseRole()
    }
}
